package com.drakon.client

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HudDef(val id: String, val name: String, val x: Float, val y: Float, val size: Float)

val HUDS = listOf(
    HudDef("clock", "Clock", 0.03f, 0.04f, 16f),
    HudDef("battery", "Battery", 0.80f, 0.04f, 16f),
    HudDef("ram", "RAM", 0.80f, 0.12f, 16f),
    HudDef("temp", "Temp", 0.80f, 0.20f, 16f),
    HudDef("crosshair", "Crosshair", 0.50f, 0.50f, 28f),
)
val HUD_COLORS = listOf(0xFFFFFFFF, 0xFFE11D2E, 0xFFFFD43B, 0xFF4ADE80)

/** Real device values only. */
fun hudText(c: Context, id: String): String {
    val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    return when (id) {
        "clock" -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        "battery" -> {
            val l = b?.getIntExtra("level", -1) ?: -1
            val s = b?.getIntExtra("scale", 100) ?: 100
            if (l < 0) "BAT --" else "BAT ${l * 100 / s}%"
        }
        "ram" -> {
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            "RAM ${(mi.totalMem - mi.availMem) * 100 / mi.totalMem}%"
        }
        "temp" -> "TEMP ${(b?.getIntExtra("temperature", 0) ?: 0) / 10f}C"
        else -> ""
    }
}

class CrossView(c: Context) : View(c) {
    var color = Color.WHITE
    private val paint = Paint()
    override fun onDraw(canvas: Canvas) {
        paint.color = color
        paint.strokeWidth = 3f * resources.displayMetrics.density
        val w = width.toFloat()
        canvas.drawLine(0f, w / 2, w, w / 2, paint)
        canvas.drawLine(w / 2, 0f, w / 2, w, paint)
    }
}

class OverlayService : Service() {
    companion object { @Volatile var running = false }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val views = mutableMapOf<String, View>()
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("drakon", "Drakon HUD", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "drakon")
            .setContentTitle("Drakon HUD running")
            .setContentText("Tap to open Drakon Client")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, 1 shl 30) // FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        else startForeground(1, n)
        handler.post(tick)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        views.values.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        views.clear()
        super.onDestroy()
    }

    private fun screen(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.let { it.width() to it.height() }
        else resources.displayMetrics.let { it.widthPixels to it.heightPixels }

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun refresh() {
        val (sw, sh) = screen()
        val dens = resources.displayMetrics.density
        for (d in HUDS) {
            val id = d.id
            if (!prefs.bool("${id}_on", true)) {
                views.remove(id)?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                continue
            }
            val fx = prefs.float("${id}_x", d.x)
            val fy = prefs.float("${id}_y", d.y)
            val s = prefs.float("${id}_s", d.size)
            val col = HUD_COLORS[prefs.float("${id}_c", 0f).toInt().coerceIn(0, HUD_COLORS.size - 1)].toInt()
            val alpha = prefs.float("${id}_a", 1f)
            val v = views[id]
            if (id == "crosshair") {
                val px = (s * dens).toInt()
                val cv = (v as? CrossView) ?: CrossView(this).also { views[id] = it; wm.addView(it, lp(px, px)) }
                cv.color = col; cv.alpha = alpha; cv.invalidate()
                val p = cv.layoutParams as WindowManager.LayoutParams
                p.width = px; p.height = px
                p.x = (fx * sw - px / 2f).toInt(); p.y = (fy * sh - px / 2f).toInt()
                wm.updateViewLayout(cv, p)
            } else {
                val tv = (v as? TextView) ?: TextView(this).also {
                    it.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                    it.setPadding(12, 6, 12, 6)
                    it.setShadowLayer(3f, 1f, 1f, Color.BLACK)
                    views[id] = it; wm.addView(it, lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT))
                }
                tv.text = hudText(this, id)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, s)
                tv.setTextColor(col)
                tv.setBackgroundColor(if (prefs.float("${id}_bg", 0f) > 0f) 0x99000000.toInt() else 0)
                tv.alpha = alpha
                val p = tv.layoutParams as WindowManager.LayoutParams
                p.x = (fx * sw).toInt(); p.y = (fy * sh).toInt()
                wm.updateViewLayout(tv, p)
            }
        }
    }
}
