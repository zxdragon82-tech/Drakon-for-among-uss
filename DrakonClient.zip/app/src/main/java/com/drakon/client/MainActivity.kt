package com.drakon.client

import android.Manifest
import android.app.ActivityManager
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.compose.ui.geometry.Offset
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val MC_PACKAGE = "com.mojang.minecraftpe"
const val TARGET_VERSION = "26.60"   // compared against Minecraft's versionName

val Red = Color(0xFFE11D2E)
val Bg = Color(0xFF0A0A0A)
val Panel = Color(0xFF1A1A1A)
val Mono = FontFamily.Monospace
val LocalGlow = staticCompositionLocalOf<() -> Float> { { 0.8f } }

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("drakon", Context.MODE_PRIVATE)
    fun bool(k: String, d: Boolean = false) = sp.getBoolean(k, d)
    fun setBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    fun int(k: String, d: Int) = sp.getInt(k, d)
    fun setInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun float(k: String, d: Float) = sp.getFloat(k, d)
    fun setFloat(k: String, v: Float) = sp.edit().putFloat(k, v).apply()
    fun str(k: String, d: String = "") = sp.getString(k, d) ?: d
    fun setStr(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun clear() = sp.edit().clear().apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs(this)
        setContent { DrakonApp(p) }
    }
}

data class Mc(val installed: Boolean, val version: String?, val supported: Boolean)

fun detectMc(c: Context): Mc = try {
    val v = c.packageManager.getPackageInfo(MC_PACKAGE, 0).versionName ?: ""
    Mc(true, v, v.contains(TARGET_VERSION))
} catch (e: Exception) { Mc(false, null, false) }

@Composable
fun Card2(content: @Composable ColumnScope.() -> Unit) {
    val glow = LocalGlow.current
    Column(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
            .background(Panel, RoundedCornerShape(14.dp))
            .drawBehind {
                drawRoundRect(Red.copy(alpha = glow()), cornerRadius = CornerRadius(14.dp.toPx()), style = Stroke(2.dp.toPx()))
            }
            .padding(14.dp),
        content = content
    )
}

@Composable fun H(t: String) = Text(t, color = Red, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 16.sp)
@Composable fun T(t: String, c: Color = Color.White) = Text(t, color = c, fontFamily = Mono, fontSize = 13.sp)

@Composable
fun DrakonApp(p: Prefs) {
    var tab by remember { mutableIntStateOf(0) }
    var profile by remember { mutableIntStateOf(p.int("profile", 1)) } // 0 perf, 1 balanced, 2 visual
    var reduce by remember { mutableStateOf(p.bool("reduce")) }
    var resetKey by remember { mutableIntStateOf(0) }
    val anim = profile != 0 && !reduce
    val pulse = rememberInfiniteTransition(label = "glow").animateFloat(
        0.3f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "g"
    )
    val glow: () -> Float = { if (anim) pulse.value else 0.8f }
    val tabs = listOf("HOME", "PERF", "HUD", "PACKS", "SET")

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel)) {
        CompositionLocalProvider(LocalGlow provides glow) {
            Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
                    Text("DRAKON CLIENT", color = Red, fontFamily = Mono, fontWeight = FontWeight.Black, fontSize = 26.sp)
                    Text("UNLEASH YOUR GAME.", color = Color.Gray, fontFamily = Mono, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    key(resetKey) {
                        Crossfade(tab, animationSpec = tween(if (anim) 300 else 0), label = "nav") { t ->
                            Column {
                                when (t) {
                                    0 -> Home(p)
                                    1 -> Perf()
                                    2 -> Editor(p)
                                    3 -> Packs(p)
                                    else -> SettingsScreen(p, profile, { profile = it; p.setInt("profile", it) },
                                        reduce, { reduce = it; p.setBool("reduce", it) },
                                        { p.clear(); profile = 1; reduce = false; resetKey++ })
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().background(Panel)) {
                    tabs.forEachIndexed { i, n ->
                        Box(Modifier.weight(1f).clickable { tab = i }.padding(vertical = 14.dp), Alignment.Center) {
                            Text(n, color = if (i == tab) Red else Color.Gray, fontFamily = Mono,
                                fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun Home(p: Prefs) {
    val c = LocalContext.current
    val mc = remember { detectMc(c) }
    val enabled = HUDS.count { p.bool("${it.id}_on", true) }
    Card2 {
        H("MINECRAFT")
        T(if (!mc.installed) "Not installed (package $MC_PACKAGE not found)" else "Installed: ${mc.version}")
        T("Target: $TARGET_VERSION", Color.Gray)
        T(
            when {
                !mc.installed -> "Status: UNAVAILABLE"
                mc.supported -> "Status: SUPPORTED"
                else -> "Status: UNSUPPORTED VERSION - features may not match"
            }, if (mc.supported) Color(0xFF4ADE80) else Red
        )
    }
    OverlayCard()
    Card2 {
        H("CLIENT")
        T("Drakon Client v0.2.0")
        T("HUD elements enabled: $enabled / ${HUDS.size}")
    }
    Card2 {
        H("FEATURE AVAILABILITY")
        listOf(
            "UI, themes, HUD layout editor" to "Available",
            "Minecraft install/version detection" to "Available",
            "Import .mcpack into Minecraft" to "Available",
            "In-game overlay HUD (needs overlay permission)" to "Available",
            "Coords/health via behavior pack" to "Not built yet",
            "Minecraft FPS, ping, CPS, keystrokes" to "Unavailable (Android blocks it)",
        ).forEach { (a, b) -> T("$a: $b", if (b == "Available") Color(0xFF4ADE80) else Color.Gray) }
    }
}

@Composable
fun Perf() {
    val c = LocalContext.current
    var rows by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    LaunchedEffect(Unit) {
        while (true) {
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra("level", -1) ?: -1
            val sc = b?.getIntExtra("scale", 100) ?: 100
            val tmp = (b?.getIntExtra("temperature", 0) ?: 0) / 10f
            val total = mi.totalMem / 1048576
            val used = total - mi.availMem / 1048576
            rows = listOf(
                "RAM (device)" to "$used / $total MB",
                "Battery" to if (lvl >= 0) "${lvl * 100 / sc}%" else "n/a",
                "Battery temp" to "$tmp C",
                "Device" to "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
                "Android" to "${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})",
            )
            delay(2000)
        }
    }
    Card2 { H("PERFORMANCE CENTER"); rows.forEach { (a, b) -> T("$a: $b") } }
    Card2 {
        T("Minecraft's FPS cannot be read from another Android app, so none is shown. " +
            "Profiles only change Drakon's own UI.", Color.Gray)
    }
}

@Composable
fun OverlayCard() {
    val c = LocalContext.current
    var running by remember { mutableStateOf(OverlayService.running) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    Card2 {
        H("IN-GAME OVERLAY")
        T("Draws your enabled HUDs over Minecraft. Needs 'Display over other apps'.", Color.Gray)
        T("Status: ${if (running) "RUNNING" else "STOPPED"}", if (running) Color(0xFF4ADE80) else Color.Gray)
        Spacer(Modifier.height(8.dp))
        Row {
            Button(onClick = {
                if (running) {
                    c.stopService(Intent(c, OverlayService::class.java)); running = false
                } else if (!Settings.canDrawOverlays(c)) {
                    c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
                } else {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java)); running = true
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text(if (running) "STOP" else "START") }
            Spacer(Modifier.width(10.dp))
            Button(onClick = {
                val i = c.packageManager.getLaunchIntentForPackage(MC_PACKAGE)
                if (i != null) c.startActivity(i) else Toast.makeText(c, "Minecraft not found", Toast.LENGTH_LONG).show()
            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))) { Text("LAUNCH MC") }
        }
    }
}

@Composable
fun Editor(p: Prefs) {
    val vals = remember {
        mutableStateMapOf<String, Float>().also { m ->
            HUDS.forEach { d ->
                m["${d.id}_x"] = p.float("${d.id}_x", d.x); m["${d.id}_y"] = p.float("${d.id}_y", d.y)
                m["${d.id}_s"] = p.float("${d.id}_s", d.size); m["${d.id}_a"] = p.float("${d.id}_a", 1f)
                m["${d.id}_c"] = p.float("${d.id}_c", 0f); m["${d.id}_bg"] = p.float("${d.id}_bg", 0f)
            }
        }
    }
    val en = remember { mutableStateMapOf<String, Boolean>().also { m -> HUDS.forEach { m[it.id] = p.bool("${it.id}_on", true) } } }
    fun set(k: String, v: Float) { vals[k] = v; p.setFloat(k, v) }
    var sel by remember { mutableStateOf("clock") }
    var box by remember { mutableStateOf(IntSize(1, 1)) }
    var tickN by remember { mutableIntStateOf(0) }
    val c = LocalContext.current
    LaunchedEffect(Unit) { while (true) { delay(2000); tickN++ } }

    Card2 {
        H("HUD EDITOR")
        T("Drag elements. Saved automatically. Press START on Home to show them over Minecraft.", Color.Gray)
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().aspectRatio(16 / 9f).onSizeChanged { box = it }
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF3B6FB0), Color(0xFF4C8B3A), Color(0xFF5A3E26))))
        ) {
            HUDS.filter { en[it.id] == true }.forEach { d ->
                val id = d.id
                val ps = vals["${id}_s"]!! * 0.6f // preview is scaled down from a real screen
                val col = Color(HUD_COLORS[vals["${id}_c"]!!.toInt()])
                val mod = Modifier
                    .offset {
                        val half = if (id == "crosshair") ps.dp.toPx() / 2 else 0f
                        IntOffset((vals["${id}_x"]!! * box.width - half).toInt(), (vals["${id}_y"]!! * box.height - half).toInt())
                    }
                    .alpha(vals["${id}_a"]!!)
                    .then(if (sel == id) Modifier.border(1.dp, Red) else Modifier)
                    .pointerInput(id) {
                        detectDragGestures(onDragStart = { sel = id }) { ch, dr ->
                            ch.consume()
                            set("${id}_x", (vals["${id}_x"]!! + dr.x / box.width).coerceIn(0f, 1f))
                            set("${id}_y", (vals["${id}_y"]!! + dr.y / box.height).coerceIn(0f, 1f))
                        }
                    }
                if (id == "crosshair") {
                    Canvas(mod.size(ps.dp)) {
                        val w = this.size.width
                        val t = 2.dp.toPx()
                        drawLine(col, Offset(0f, w / 2), Offset(w, w / 2), t)
                        drawLine(col, Offset(w / 2, 0f), Offset(w / 2, w), t)
                    }
                } else {
                    val txt = remember(tickN) { hudText(c, id) }
                    Text(
                        txt, color = col, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = ps.sp,
                        modifier = mod
                            .then(if (vals["${id}_bg"]!! > 0f) Modifier.background(Color.Black.copy(alpha = 0.6f)) else Modifier)
                            .padding(horizontal = 4.dp)
                    )
                }
            }
        }
    }
    Card2 {
        Row {
            HUDS.forEach { d ->
                Text(d.name, color = if (sel == d.id) Red else Color.Gray, fontFamily = Mono, fontSize = 12.sp,
                    modifier = Modifier.clickable { sel = d.id }.padding(end = 12.dp, bottom = 8.dp))
            }
        }
        val d = HUDS.first { it.id == sel }
        T("Size")
        Slider(vals["${sel}_s"]!!, { set("${sel}_s", it) }, valueRange = if (sel == "crosshair") 10f..80f else 8f..48f)
        T("Opacity")
        Slider(vals["${sel}_a"]!!, { set("${sel}_a", it) }, valueRange = 0.2f..1f)
        T("Color")
        Row {
            HUD_COLORS.forEachIndexed { i, hc ->
                val shape = RoundedCornerShape(6.dp)
                Box(
                    Modifier.padding(end = 10.dp, top = 6.dp, bottom = 6.dp).size(30.dp).background(Color(hc), shape)
                        .then(if (vals["${sel}_c"]!!.toInt() == i) Modifier.border(2.dp, Red, shape) else Modifier)
                        .clickable { set("${sel}_c", i.toFloat()) }
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Enabled"); Spacer(Modifier.width(8.dp))
            Switch(en[sel] == true, { en[sel] = it; p.setBool("${sel}_on", it) })
            if (sel != "crosshair") {
                Spacer(Modifier.width(16.dp)); T("Background"); Spacer(Modifier.width(8.dp))
                Switch(vals["${sel}_bg"]!! > 0f, { set("${sel}_bg", if (it) 1f else 0f) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            set("${sel}_x", d.x); set("${sel}_y", d.y); set("${sel}_s", d.size)
            set("${sel}_a", 1f); set("${sel}_c", 0f); set("${sel}_bg", 0f)
        }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("RESET") }
    }
}

@Composable
fun Packs(p: Prefs) {
    val c = LocalContext.current
    var list by remember { mutableStateOf(p.str("packs").split("|").filter { it.isNotBlank() }) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val name = c.contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: "pack"
        if (!name.endsWith(".mcpack", true) && !name.endsWith(".mcaddon", true)) {
            Toast.makeText(c, "Not a .mcpack/.mcaddon file", Toast.LENGTH_LONG).show(); return@rememberLauncherForActivityResult
        }
        try {
            c.startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream"); setPackage(MC_PACKAGE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
            list = (list + name).distinct(); p.setStr("packs", list.joinToString("|"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(c, "Minecraft not found or can't open this file", Toast.LENGTH_LONG).show()
        }
    }
    Card2 {
        H("RESOURCE PACKS")
        T("Importing hands the file to Minecraft, which does the actual install. Enable packs inside the game.", Color.Gray)
        Spacer(Modifier.height(8.dp))
        Button({ picker.launch(arrayOf("*/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("IMPORT .MCPACK") }
    }
    Card2 {
        H("SENT TO MINECRAFT")
        if (list.isEmpty()) T("Nothing yet", Color.Gray) else list.forEach { T(it) }
    }
}

@Composable
fun SettingsScreen(p: Prefs, profile: Int, setProfile: (Int) -> Unit, reduce: Boolean, setReduce: (Boolean) -> Unit, reset: () -> Unit) {
    Card2 {
        H("INTERFACE PROFILE")
        listOf("Performance", "Balanced", "Visual").forEachIndexed { i, n ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(profile == i, { setProfile(i) }, colors = RadioButtonDefaults.colors(selectedColor = Red))
                T(n)
            }
        }
        T("Performance mode turns off Drakon's glow animation. It does not change Minecraft's FPS.", Color.Gray)
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Reduce animations"); Spacer(Modifier.weight(1f)); Switch(reduce, setReduce)
        }
    }
    Card2 {
        H("ABOUT")
        T("Drakon Client v0.2.0"); T("Targets Minecraft Bedrock $TARGET_VERSION", Color.Gray)
        Spacer(Modifier.height(8.dp))
        Button(reset, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("RESET SETTINGS") }
    }
}
