# Drakon Client
Android companion app for Minecraft Bedrock (target 26.60). Built with Kotlin + Jetpack Compose.

## Build with GitHub
1. Create a repo, push this folder.
2. Actions tab > "Build APK" runs automatically (or Run workflow).
3. Download the `DrakonClient-debug` artifact, unzip, install the APK.

## Status (v0.2.0)
Working: nav, Minecraft detection, RAM/battery/temp, HUD editor (drag/size/opacity/color/background/reset, saved), in-game overlay service showing Clock, Battery, RAM, Temp and a Crosshair (real device values only), .mcpack hand-off, profiles, reset.
Not built yet: behavior pack (coords/health), more HUDs, multiple saved layouts, themes/accent colors, update checker.
Impossible without game injection: Minecraft FPS, ping, CPS, keystrokes, potion effects.
