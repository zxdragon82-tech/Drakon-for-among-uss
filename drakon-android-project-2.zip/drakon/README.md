# DRAKON for Among Us (com.drakon.amongus)

## Build
1. Install Android Studio (Koala+) with SDK 34. Open this folder; let Gradle sync (it downloads Gradle 8.7 / AGP 8.5.2).
2. Debug APK (installable immediately): `./gradlew assembleDebug`  (if no wrapper script: `gradle wrapper --gradle-version 8.7` first, or run Build > Build APK in Studio)
   -> app/build/outputs/apk/debug/app-debug.apk
3. Release APK (signed):
   keytool -genkey -v -keystore drakon.jks -alias drakon -keyalg RSA -keysize 2048 -validity 10000
   export DRAKON_KEYSTORE=$PWD/drakon.jks DRAKON_STORE_PASS=... DRAKON_KEY_ALIAS=drakon DRAKON_KEY_PASS=...
   ./gradlew assembleRelease  -> app/build/outputs/apk/release/app-release.apk
4. Install: `adb install app-debug.apk` (enable USB debugging) or copy to the phone.

## What really works
Device info, display-mode detection, display-mode/refresh preference for DRAKON's own window, FPS measurement of DRAKON's window,
battery temperature, Among Us detection/launch, persistent settings.
## Unavailable (by design)
Changing Among Us's render resolution or removing its FPS cap - no supported Android mechanism exists.
