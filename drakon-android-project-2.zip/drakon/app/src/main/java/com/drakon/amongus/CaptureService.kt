package com.drakon.amongus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper

/** Frame Lab prototype: captures the screen (user-approved MediaProjection) and builds a 50/50 blended in-between frame. */
class CaptureService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var capFps = 0f
        @Volatile var genCount = 0L
        @Volatile var blendMs = 0f
        @Volatile var a: Bitmap? = null
        @Volatile var mid: Bitmap? = null
        @Volatile var b: Bitmap? = null
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var prev: Bitmap? = null
    private var frames = 0
    private var t0 = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "drakon_cap"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "DRAKON Frame Lab", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("DRAKON Frame Lab is capturing")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))

        val dm = resources.displayMetrics
        val w = dm.widthPixels / 2; val h = dm.heightPixels / 2
        thread = HandlerThread("drakon-cap").also { it.start() }
        val hd = Handler(thread!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay("drakon", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, hd)
        reader!!.setOnImageAvailableListener({ onFrame(it) }, hd)
        running = true; genCount = 0; frames = 0; t0 = 0L; capFps = 0f
        return START_NOT_STICKY
    }

    private fun onFrame(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val p = img.planes[0]
            val bw = p.rowStride / p.pixelStride
            val full = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            val cur = if (bw != img.width) Bitmap.createBitmap(full, 0, 0, img.width, img.height) else full
            val now = System.nanoTime()
            if (t0 == 0L) t0 = now
            frames++
            if (now - t0 >= 1_000_000_000L) { capFps = frames * 1e9f / (now - t0); frames = 0; t0 = now }
            val pv = prev
            if (pv != null && pv.width == cur.width && pv.height == cur.height) {
                val s = System.nanoTime()
                val m = blend(pv, cur)
                blendMs = (System.nanoTime() - s) / 1e6f
                genCount++
                if (genCount == 1L || genCount % 30L == 0L) { a = pv; mid = m; b = cur }
            }
            prev = cur
        } finally { img.close() }
    }

    private fun blend(x: Bitmap, y: Bitmap): Bitmap {
        val w = x.width; val h = x.height; val n = w * h
        val px = IntArray(n); val py = IntArray(n)
        x.getPixels(px, 0, w, 0, 0, w, h); y.getPixels(py, 0, w, 0, 0, w, h)
        val mask = 0xFEFEFEFE.toInt()
        for (i in 0 until n) px[i] = (((px[i] and mask) ushr 1) + ((py[i] and mask) ushr 1)) or 0xFF000000.toInt()
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    override fun onDestroy() {
        running = false
        vd?.release(); reader?.close(); projection?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
}
