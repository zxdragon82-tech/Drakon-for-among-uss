package com.drakon.amongus

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.DisplayMetrics
import android.view.Choreographer
import android.view.Display
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.media.projection.MediaProjectionManager
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    companion object {
        const val GAME = "com.innersloth.spacemafia"
        const val RED = 0xFFE50914.toInt()
        const val CARD = 0xFF141414.toInt()
        const val GREY = 0xFFAAAAAA.toInt()
        const val GREEN = 0xFF4CAF50.toInt()
        const val ORANGE = 0xFFFF7043.toInt()
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var content: FrameLayout
    private var tab = 0
    private var monitoring = false
    private var measuredFps = 0f
    private var frames = 0
    private var lastNs = 0L
    private var tick: (() -> Unit)? = null
    private val gpu by lazy { gpuInfo() }

    private val overlayLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", r.resultCode).putExtra("data", d))
            Toast.makeText(this, "Overlay on. Switch to Among Us.", Toast.LENGTH_LONG).show()
        }
    }

    private fun startOverlay() {
        if (Build.VERSION.SDK_INT < 34) {
            Toast.makeText(this, "Needs Android 14+ (single-app capture). Your phone: Android ${Build.VERSION.RELEASE}.", Toast.LENGTH_LONG).show(); return
        }
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' for DRAKON, then try again.", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))); return
        }
        overlayLauncher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", r.resultCode).putExtra("data", d))
            Toast.makeText(this, "Capturing. Open Among Us, play a bit, come back and tap Stop.", Toast.LENGTH_LONG).show()
            show(4)
        }
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (lastNs == 0L) lastNs = t
            frames++
            if (t - lastNs >= 1_000_000_000L) {
                measuredFps = frames * 1e9f / (t - lastNs)
                frames = 0; lastNs = t
                tick?.invoke()
            }
            if (monitoring) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("drakon", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            fitsSystemWindows = true
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply {
            setBackgroundColor(0xFF0B0B0B.toInt())
            menu.add(0, 0, 0, "Home").setIcon(android.R.drawable.ic_menu_compass)
            menu.add(0, 1, 1, "Monitor").setIcon(android.R.drawable.ic_menu_view)
            menu.add(0, 2, 2, "Settings").setIcon(android.R.drawable.ic_menu_preferences)
            menu.add(0, 3, 3, "About").setIcon(android.R.drawable.ic_menu_info_details)
            menu.add(0, 4, 4, "Lab").setIcon(android.R.drawable.ic_menu_camera)
            setOnItemSelectedListener { show(it.itemId); true }
        }
        root.addView(nav)
        setContentView(root)
        applyFullscreen()
    }

    override fun onResume() { super.onResume(); show(tab) }
    override fun onPause() { super.onPause(); stopMonitor() }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 14f, color: Int = GREY, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
        }

    private fun row(k: String, v: String, ok: Boolean? = null): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tv(k), LinearLayout.LayoutParams(0, -2, 0.42f))
            val mark = when (ok) { true -> "✔ "; false -> "✖ "; null -> "" }
            val c = when (ok) { true -> GREEN; false -> ORANGE; null -> Color.WHITE }
            addView(tv(mark + v, 14f, c), LinearLayout.LayoutParams(0, -2, 0.58f))
        }

    private fun card(title: String, vararg views: View) = MaterialCardView(this).apply {
        radius = dp(20).toFloat(); setCardBackgroundColor(CARD)
        strokeColor = 0xFF2A2A2A.toInt(); strokeWidth = dp(1); cardElevation = 0f
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            addView(tv(title, 12f, RED, true))
            views.forEach { addView(it) }
        })
    }

    private fun button(t: String, filled: Boolean = true, onClick: () -> Unit) = MaterialButton(this).apply {
        text = t; isAllCaps = false; cornerRadius = dp(16)
        if (filled) backgroundTintList = ColorStateList.valueOf(RED)
        else { backgroundTintList = ColorStateList.valueOf(CARD); strokeWidth = dp(1); strokeColor = ColorStateList.valueOf(RED) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) }
    }

    private fun toggle(options: List<Pair<String, String>>, current: String, onSel: (String) -> Unit): MaterialButtonToggleGroup {
        val g = MaterialButtonToggleGroup(this).apply { isSingleSelection = true; isSelectionRequired = true }
        val ids = HashMap<Int, String>()
        options.forEach { (label, value) ->
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                id = View.generateViewId(); text = label; isAllCaps = false
            }
            ids[b.id] = value
            g.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
            if (value == current) g.check(b.id)
        }
        g.addOnButtonCheckedListener { _, id, checked -> if (checked) onSel(ids[id]!!) }
        return g
    }

    private fun show(t: Int) {
        tab = t
        stopMonitor()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), dp(16))
        }
        when (t) { 0 -> home(page); 1 -> monitor(page); 2 -> settings(page); 3 -> about(page); else -> lab(page) }
        content.removeAllViews()
        val sv = ScrollView(this).apply { addView(page); alpha = 0f }
        content.addView(sv)
        sv.animate().alpha(1f).setDuration(250).start()
    }

    // ---------- device queries ----------
    @Suppress("DEPRECATION")
    private fun disp(): Display = windowManager.defaultDisplay

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics = DisplayMetrics().also { disp().getRealMetrics(it) }

    private fun modes() = disp().supportedModes.toList()

    private fun ramInfo(): String {
        val mi = android.app.ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
        return "%.1f GB free of %.1f GB".format(mi.availMem / 1e9, mi.totalMem / 1e9)
    }

    private fun gpuInfo(): String = try {
        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2); EGL14.eglInitialize(d, v, 0, v, 1)
        val attr = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE)
        val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        EGL14.eglChooseConfig(d, attr, 0, cfgs, 0, 1, n, 0)
        val ctx = EGL14.eglCreateContext(d, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreatePbufferSurface(d, cfgs[0],
            intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(d, surf, surf, ctx)
        val s = "${GLES20.glGetString(GLES20.GL_VENDOR)} ${GLES20.glGetString(GLES20.GL_RENDERER)}"
        EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(d, surf); EGL14.eglDestroyContext(d, ctx); EGL14.eglTerminate(d)
        s
    } catch (e: Throwable) { "Unavailable" }

    private fun batteryTemp(): Float? {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) null else t / 10f
    }

    private fun gameVersion(): String? = try {
        packageManager.getPackageInfo(GAME, 0).versionName
    } catch (e: Exception) { null }

    private fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)

    private fun fpsSupported(f: Int) = modes().any {
        val r = it.refreshRate / f
        r >= 0.97f && abs(r - r.roundToInt()) < 0.03f
    }

    private fun targetSize(): Pair<Int, Int>? = when (prefs.getString("res", "native")) {
        "720" -> 1280 to 720
        "1080" -> 1920 to 1080
        "custom" -> Pair(prefs.getInt("cw", 0), prefs.getInt("ch", 0)).takeIf { it.first > 0 && it.second > 0 }
        else -> null
    }

    private fun modesFor(w: Int, h: Int) = modes().filter {
        (it.physicalWidth == w && it.physicalHeight == h) || (it.physicalWidth == h && it.physicalHeight == w)
    }

    private fun resolutionReport(): Pair<Boolean?, String> {
        val t = targetSize()
        if (t == null) return if (prefs.getString("res", "native") == "custom")
            false to "Enter a custom width and height in Settings." else true to "Native display resolution is always available."
        val m = modesFor(t.first, t.second)
        return if (m.isNotEmpty()) true to "${t.first}×${t.second} is a real display mode on this device (up to ${m.maxOf { it.refreshRate }.roundToInt()} Hz)."
        else false to "${t.first}×${t.second} is NOT a display mode this device exposes. It cannot be applied."
    }

    private fun applyFullscreen() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        WindowCompat.setDecorFitsSystemWindows(window, !prefs.getBoolean("fs", false))
        if (prefs.getBoolean("fs", false)) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun applySettings() {
        val f = prefs.getInt("fps", 60)
        var cands = modes()
        val t = targetSize()
        if (t != null) modesFor(t.first, t.second).takeIf { it.isNotEmpty() }?.let { cands = it }
        val best = cands.filter {
            val r = it.refreshRate / f; r.roundToInt() >= 1 && abs(r - r.roundToInt()) < 0.03f
        }.minByOrNull { it.refreshRate }
        val lp = window.attributes
        val msg = if (best != null) {
            lp.preferredDisplayModeId = best.modeId
            "Applied to DRAKON window: ${best.physicalWidth}×${best.physicalHeight} @ ${best.refreshRate.roundToInt()} Hz"
        } else "No matching display mode for ${f} FPS; kept system default."
        window.attributes = lp
        applyFullscreen()
        prefs.edit().putString("last", msg).apply()
        Toast.makeText(this, "$msg\nAmong Us itself is not modified.", Toast.LENGTH_LONG).show()
        show(tab)
    }

    private fun launchGame() {
        val i = packageManager.getLaunchIntentForPackage(GAME)
        if (i == null) Toast.makeText(this, "Among Us is not installed.", Toast.LENGTH_SHORT).show()
        else startActivity(i)
    }

    // ---------- screens ----------
    private fun home(p: LinearLayout) {
        val dm = realMetrics()
        p.addView(tv("DRAKON", 38f, RED, true))
        p.addView(tv("for Among Us", 16f, Color.WHITE))
        p.addView(tv("Display & frame-rate utility. Client-side only.", 12f).apply { setPadding(0, 0, 0, dp(14)) })

        val supportedCount = listOf(true, fpsSupported(30), fpsSupported(45), fpsSupported(60)).count { it }
        p.addView(card("DEVICE COMPATIBILITY",
            row("Device", "${Build.MANUFACTURER} ${Build.MODEL}"),
            row("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"),
            row("Screen", "${dm.widthPixels}×${dm.heightPixels} @ ${dm.densityDpi} dpi"),
            row("Refresh", "${disp().refreshRate.roundToInt()} Hz now, max ${modes().maxOf { it.refreshRate }.roundToInt()} Hz"),
            row("RAM", ramInfo()),
            row("GPU", gpu),
            row("FPS targets", "$supportedCount of 4 checks pass (see Settings)", supportedCount >= 3)))

        val v = gameVersion()
        p.addView(card("AMONG US",
            row("Status", if (v != null) "Installed" else "Not installed", v != null),
            row("Version", v ?: "—")))

        val res = prefs.getString("res", "native")!!
        p.addView(card("CURRENT CONFIGURATION",
            row("Resolution", resLabel(res)),
            row("FPS target", "${prefs.getInt("fps", 60)} FPS (display refresh preference)"),
            row("Fullscreen", if (prefs.getBoolean("fs", false)) "On" else "Off"),
            row("Last applied", prefs.getString("last", "Nothing applied yet")!!)))

        p.addView(button("Apply Settings") { applySettings() })
        p.addView(button("Launch Among Us", false) { launchGame() })
    }

    private fun resLabel(r: String) = when (r) {
        "720" -> "720p HD"; "1080" -> "1080p Full HD"
        "custom" -> "Custom ${prefs.getInt("cw", 0)}×${prefs.getInt("ch", 0)}"
        else -> "Native"
    }

    private fun monitor(p: LinearLayout) {
        p.addView(tv("Live Monitor", 24f, Color.WHITE, true))
        val big = tv("--", 56f, RED, true)
        val status = row("Status", "Measuring…")
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(card("DRAKON WINDOW FPS", big, tv("Measured with Choreographer on this app's own window.", 12f)))
        p.addView(card("DISPLAY", holder))
        p.addView(tv("Android does not let regular apps read another app's FPS, so Among Us's own frame rate is not measured here. " +
            "Display refresh rate is the maximum your screen can show, not the game's frame rate.", 12f))

        fun refresh() {
            big.text = "%.0f".format(measuredFps)
            val temp = batteryTemp()
            val d = disp(); val m = d.mode
            val ratio = measuredFps / d.refreshRate
            val perf = when { measuredFps == 0f -> "Measuring…"; ratio >= 0.9f -> "Smooth"; ratio >= 0.6f -> "Moderate"; else -> "Struggling" }
            holder.removeAllViews()
            holder.addView(row("Resolution", "${m.physicalWidth}×${m.physicalHeight}"))
            holder.addView(row("Refresh rate", "${d.refreshRate.roundToInt()} Hz"))
            holder.addView(row("Temperature", if (temp != null) "%.1f °C (battery sensor)".format(temp) else "Not accessible", temp?.let { it < 42f }))
            holder.addView(row("Performance", perf, if (measuredFps == 0f) null else ratio >= 0.9f))
        }
        refresh()
        tick = { refresh() }
        monitoring = true; frames = 0; lastNs = 0L
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun stopMonitor() {
        monitoring = false; tick = null
        Choreographer.getInstance().removeFrameCallback(frameCb)
    }

    private fun settings(p: LinearLayout) {
        p.addView(tv("Settings", 24f, Color.WHITE, true))

        val wEt = EditText(this).apply { hint = "Width"; inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(GREY)
            prefs.getInt("cw", 0).takeIf { it > 0 }?.let { setText(it.toString()) } }
        val hEt = EditText(this).apply { hint = "Height"; inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(GREY)
            prefs.getInt("ch", 0).takeIf { it > 0 }?.let { setText(it.toString()) } }
        val customRow = LinearLayout(this).apply {
            addView(wEt, LinearLayout.LayoutParams(0, -2, 1f)); addView(hEt, LinearLayout.LayoutParams(0, -2, 1f))
        }
        fun saveCustom() {
            prefs.edit().putInt("cw", wEt.text.toString().toIntOrNull() ?: 0)
                .putInt("ch", hEt.text.toString().toIntOrNull() ?: 0).apply()
        }

        val resBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshReport() {
            resBox.removeAllViews()
            val (ok, msg) = resolutionReport()
            resBox.addView(row("Selected", resLabel(prefs.getString("res", "native")!!)))
            resBox.addView(row("Device support", msg, ok))
            resBox.addView(tv("This is DISPLAY resolution (the screen's output mode). It does not change Among Us's internal rendering resolution; Android gives apps no way to do that.", 12f))
        }
        refreshReport()

        p.addView(card("RESOLUTION",
            toggle(listOf("Native" to "native", "720p" to "720", "1080p" to "1080", "Custom" to "custom"),
                prefs.getString("res", "native")!!) { prefs.edit().putString("res", it).apply(); saveCustom(); refreshReport() },
            customRow, resBox))

        val f = prefs.getInt("fps", 60)
        val fpsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(30, 45, 60).forEach { fpsBox.addView(row("$it FPS", if (fpsSupported(it)) "Display can pace this evenly" else "No matching refresh rate", fpsSupported(it))) }
        fpsBox.addView(tv("Sets the refresh-rate preference of DRAKON's own window, which can improve frame pacing there. " +
            "It cannot raise or remove Among Us's internal FPS cap, and DRAKON never claims otherwise.", 12f))
        p.addView(card("FPS TARGET",
            toggle(listOf("30" to "30", "45" to "45", "60" to "60"), f.toString()) { prefs.edit().putInt("fps", it.toInt()).apply() },
            fpsBox))

        val dm = realMetrics(); val g = gcd(dm.widthPixels, dm.heightPixels)
        val sw = MaterialSwitch(this).apply {
            text = "Fullscreen (hide system bars in DRAKON)"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("fs", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("fs", c).apply(); applyFullscreen() }
        }
        p.addView(card("DISPLAY",
            sw,
            row("Aspect ratio", "${dm.widthPixels / g}:${dm.heightPixels / g} (%.2f:1)".format(maxOf(dm.widthPixels, dm.heightPixels).toFloat() / minOf(dm.widthPixels, dm.heightPixels))),
            row("Density", "${dm.densityDpi} dpi (scale ${"%.2f".format(dm.density)}x)"),
            row("Font scale", "%.2fx".format(resources.configuration.fontScale)),
            tv("Among Us handles its own aspect ratio and UI scaling; DRAKON only reports these values.", 12f)))

        p.addView(card("UNAVAILABLE FEATURES",
            row("Change Among Us render resolution", "Needs game modification", false),
            row("Remove Among Us FPS cap", "Needs game modification", false),
            row("Inject into game / root tweaks", "Not supported", false),
            tv("These are intentionally disabled instead of faked.", 12f)))

        p.addView(button("Apply Settings") { saveCustom(); applySettings() })
    }

    private fun lab(p: LinearLayout) {
        p.addView(tv("Frame Lab (prototype)", 24f, Color.WHITE, true))
        p.addView(tv("Captures the screen and builds an in-between frame from two real frames. This is a simple 50/50 blend, not motion-compensated, and it does NOT change what Among Us shows on screen.", 12f).apply { setPadding(0, 0, 0, dp(10)) })
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val imgs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        p.addView(card("CAPTURE STATS", stats))
        p.addView(card("LAST SAMPLE (Real A, Generated, Real B)", imgs))
        p.addView(tv("OVERLAY (experimental, Android 14+): open Among Us first, come back here, tap Start overlay, and choose Among Us in 'Share one app'.", 12f))
        p.addView(button("Start overlay") { startOverlay() })
        p.addView(button("Stop overlay", false) { stopService(Intent(this, OverlayService::class.java)) })
        p.addView(button("Start capture") {
            projLauncher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
        })
        p.addView(button("Stop capture", false) { stopService(Intent(this, CaptureService::class.java)) })
        p.addView(tv("Screen changes/s counts frames Android delivers when the picture changes; a static screen delivers none. Generated frames exist only inside DRAKON for now.", 12f))
        fun refresh() {
            stats.removeAllViews()
            stats.addView(row("Capture", if (CaptureService.running) "Running" else "Stopped", CaptureService.running))
            stats.addView(row("Screen changes/s", "%.0f".format(CaptureService.capFps)))
            stats.addView(row("Frames generated", CaptureService.genCount.toString()))
            stats.addView(row("Blend cost", "%.1f ms".format(CaptureService.blendMs)))
            imgs.removeAllViews()
            listOf("Real A" to CaptureService.a, "Generated" to CaptureService.mid, "Real B" to CaptureService.b).forEach { (l, bm) ->
                if (bm != null) imgs.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(tv(l, 11f))
                    addView(ImageView(this@MainActivity).apply { setImageBitmap(bm); adjustViewBounds = true }, LinearLayout.LayoutParams(-1, -2))
                }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
        refresh()
        tick = { refresh() }
        monitoring = true; frames = 0; lastNs = 0L
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun about(p: LinearLayout) {
        p.addView(tv("DRAKON", 38f, RED, true))
        p.addView(tv("DRAKON for Among Us — Built for better gaming.", 16f, Color.WHITE))
        p.addView(card("VERSION", tv("1.0.0 · com.drakon.amongus")))
        p.addView(card("WHAT THIS APP IS",
            tv("A client-side display and frame-rate utility. It uses official Android display-mode APIs, requests no permissions and needs no root. " +
                "It does not modify Among Us, its network traffic, anti-cheat or servers, and it is not affiliated with Innersloth.")))
    }
}
