package com.drakon.amongus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/** Draws a full-screen, touch-through overlay that shows captured Among Us frames plus a blended in-between frame. */
class FrameView(c: Context) : View(c) {
    var base: Bitmap? = null
    var top: Bitmap? = null
    var topAlpha = 255
    var srcW = 0
    var srcH = 0
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = Rect()
    override fun onDraw(c: Canvas) {
        if (srcW == 0) return
        dst.set(0, 0, width, height); src.set(0, 0, srcW, srcH)
        base?.let { paint.alpha = 255; c.drawBitmap(it, src, dst, paint) }
        top?.let { paint.alpha = topAlpha; c.drawBitmap(it, src, dst, paint) }
    }
}

class OverlayService : Service() {
    companion object {
        @Volatile var running = false
        const val SCALE = 0.75f   // capture scale; lower = faster, blurrier
    }

    private val ui = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var view: FrameView? = null
    private val pool = arrayOfNulls<Bitmap>(3)
    private var pi = 0
    private var shown: Bitmap? = null
    private var lastArrival = 0L
    private val settle = Runnable {
        view?.let { it.base = shown; it.top = null; it.topAlpha = 255; it.invalidate() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "drakon_overlay"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "DRAKON Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("DRAKON overlay is running")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(2, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (data == null || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }

        val wm = getSystemService(WindowManager::class.java)
        val fv = FrameView(this).also { view = it }
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(fv, lp)

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
            override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
                fv.visibility = if (isVisible) View.VISIBLE else View.INVISIBLE
            }
        }, ui)

        val (a, b) = screenSize(wm)
        val w = (maxOf(a, b) * SCALE).toInt() and 1.inv()   // Among Us runs in landscape
        val h = (minOf(a, b) * SCALE).toInt() and 1.inv()
        thread = HandlerThread("drakon-overlay").also { it.start() }
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        vd = projection!!.createVirtualDisplay("drakon-ov", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, Handler(thread!!.looper))
        reader!!.setOnImageAvailableListener({ onFrame(it) }, Handler(thread!!.looper))
        running = true
        return START_NOT_STICKY
    }

    private fun screenSize(wm: WindowManager): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        else {
            val d = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(d)
            d.widthPixels to d.heightPixels
        }

    private fun onFrame(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val p = img.planes[0]
            val bw = p.rowStride / p.pixelStride
            var bm = pool[pi]
            if (bm == null || bm.width != bw || bm.height != img.height) {
                bm = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888); pool[pi] = bm
            }
            bm.copyPixelsFromBuffer(p.buffer)
            pi = (pi + 1) % 3
            val frame = bm; val w = img.width; val h = img.height
            ui.post { present(frame, w, h) }
        } finally { img.close() }
    }

    private fun present(bm: Bitmap, w: Int, h: Int) {
        val v = view ?: return
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastArrival).coerceIn(8L, 100L); lastArrival = now
        v.srcW = w; v.srcH = h
        ui.removeCallbacks(settle)
        val prev = shown
        if (prev != null) {
            v.base = prev; v.top = bm; v.topAlpha = 128; v.invalidate()   // generated in-between frame
            ui.postDelayed(settle, dt / 2)                                // then the real frame
        } else { v.base = bm; v.top = null; v.invalidate() }
        shown = bm
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        try { view?.let { getSystemService(WindowManager::class.java).removeView(it) } } catch (e: Exception) {}
        vd?.release(); reader?.close(); projection?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
}
