plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.drakon.amongus"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.drakon.amongus"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }
    signingConfigs {
        create("release") {
            val ks = System.getenv("DRAKON_KEYSTORE")
            if (ks != null) {
                storeFile = file(ks)
                storePassword = System.getenv("DRAKON_STORE_PASS")
                keyAlias = System.getenv("DRAKON_KEY_ALIAS")
                keyPassword = System.getenv("DRAKON_KEY_PASS")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (System.getenv("DRAKON_KEYSTORE") != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
